const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const request = require('request');
const cheerio = require('cheerio'); 
const axios = require('axios');
const { response } = require('express');
const randomUA = require('modern-random-ua');
let ip_addresses = [];
let port_numbers = [];
let country = [];
var get_proxy_try_counter =  0
async function getProxy(){
    if(get_proxy_try_counter <= 40){
        var res =await  axios.get('https://api.proxyorbit.com/v1/?token=1PXP14HSwhG5c3_dDgxbgGdWEqa8dApVXO_x7txy2pc');
        if(res.data.websites.amazon != undefined){
            if(res.data.websites.amazon == true){
                return res.data.curl;
            } else{
                get_proxy_try_counter++;
                console.log(get_proxy_try_counter)
                 return getProxy();
            }
        }else{
            return false;
        }
    }else{
        return false;
    }

}

puppeteer.use(StealthPlugin());


async function startBrowser(){
    let browser;
  var proxy  = await getProxy();
  if(proxy === false){
      return {error : 'proxy cannot be obtain, mostly because a server error , chack your api call limit'}
   }
    try {
        console.log("Opening the browser......");
        browser = await puppeteer.launch({
            headless: false,
            ignoreHTTPSErrors: false,
            userAgent: randomUA.generate(),
            args: ['--disable-setuid-sandbox',
            '--shm-size=1gb',
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-infobars',
            '--window-position=0,0',
            '--ignore-certifcate-errors',
            '--ignore-certifcate-errors-spki-list',
            '--proxy-server=' + proxy
        ]
        });
    return browser;

    } catch (err) {
        console.log("Could not resolve the browser instance (browser) => ", err);
        console.log("error Name : ", err.name);
        "Could not resolve the browser instance => \n" + err
    }
}

module.exports = {
    startBrowser
};