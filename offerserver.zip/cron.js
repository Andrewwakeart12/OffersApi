const express = require('express')
const app = express()
const port = 3700
const puppeteer = require('puppeteer');
const pool =require('./database');
var cors = require('cors');
const browserObject = require('./scrapper/browser');
const scraperController = require('./scrapper/amazon/amazonController');
const { save } = require('node-cron/src/storage');
const { url } = require('./scrapper/amazon/amazonScraper');

async function init(){
  await pool.query('INSERT INTO users set username = ?, password = ? , email = ? , phone = ?', ['obe','123456789', 'edgarmarquinaruizobe@gmail.com','5841236']);

  await pool.query('INSERT INTO scraper_controller set controller=?,discount_trigger = ?, user_id = ?', ['Amazon',30,1]);
  
}
  async function search(){
    var urls = await pool.query('SELECT * FROM scraper_urls');
  
    var result = [];
    try{
     

      for(let i = 0 ; i < urls.length; i++){
        var browser = '';
        let error = 0;
        while( browser === '' && error != 30){
          browser = await browserObject.startBrowser();
 
          if(browser.error != undefined){
            return browser;            
          }
            error++;
        }
        if(browser != ''){
          let browserInstance = browser;
          let scrappedArr = await scraperController(browserInstance,urls[i].product_url);
          if(scrappedArr === undefined){
            console.log({
              error: 'data its not extracted in category : ' + urls[i].category
            })
            break;
          }else{
            console.log('Not error case : ')
            console.log(scrappedArr)
          }
            let obj = {}
            if(scrappedArr !=  undefined){
              obj =  {dataArr : scrappedArr, category: urls[i].category, controller_id : urls[i].controller_id, url_id: urls[i].id}

              result.push(obj);
            }else{
               obj= false;
               result.push(obj);
            }
        }else{
          console.log('error in browser implement');
          obj= false;
          result.push(obj);
        }

          }
            console.log(result);
            
    }catch(e){
      console.log("Error cron : ");
      console.log(e);
    }finally{
      result= result.filter(Boolean);
      if(result.length != 0 ){
        return result;
      }else{
        return {error : 'probably its because an server error or proxy check your request limit for this month'};
      }
    }

    }
  async function updateProductsInDD(){
    var categoryData = await search();
    if(categoryData.error != undefined){
      console.log(categoryData)
      return categoryData.error;
    }
    console.log(categoryData);
    var urls = await pool.query('SELECT * FROM scraper_urls');

    console.log('categoryData : ');
    console.log(categoryData);
    for(categoryProducts of categoryData){
      if(categoryProducts != false){
        console.log('categoryProducts : ');
        console.log(categoryProducts);
         
        for(product of categoryProducts.dataArr){
          product.controller_id = categoryProducts.controller_id;
          product.url_id = categoryProducts.url_id;
          product.category = categoryProducts.category;
          try{
            await pool.query('INSERT INTO scraped_data set ?', [product]);
          }catch(e){
            console.log(e);
          }
        }
      }else{
        continue;
      }

  }

  }
//let results = await search();
async function comprobate(){
await  updateProductsInDD()
}

comprobate();
//updateProductsInDD();
// cron.schedule('*/2 * * * * *', () =>{
// 	  console.log('running a task every minute');
// });
/*
delete duplicated data:

DELETE t1 FROM scraped_data t1
INNER JOIN scraped_data t2 
WHERE t1.id > t2.id AND t1.product = t2.product; 


SELECT * FROM `scraped_data` WHERE product = "Estación de carga para Xbox X|S & Xbox One - Blanco - Standard Edition"
*/