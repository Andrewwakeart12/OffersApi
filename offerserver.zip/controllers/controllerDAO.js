const controllerDAO = (config,process)=>{
    if(process == 'save'){
        const {urls, notifyByEmail, notifyByPushNotification,notifyByPhone, controllerActive , controllerId } = config
        if(urls.length != 0){
            for(url in urls){
                
            }
        }
    }
}