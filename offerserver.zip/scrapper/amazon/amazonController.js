const pageScraper = require('./amazonScraper');
const browserObject = require('../browser');

preventInfiniteLoop = 0;
preventInfiniteLoop2 = 0;
restarted = false;
async function scrapeAll(browserInstance,urls){
if(preventInfiniteLoop > 10 && preventInfiniteLoop2 < 5 && restarted === false){
    preventInfiniteLoop++;
    console.log(preventInfiniteLoop);
        let error = 0;
        var browser = '';
        while( browser === '' && error != 10){
            await browserInstance.close();
            console.log('browserInitialize');
            console.log(browser);
            preventInfiniteLoop2++;
          browser = await browserObject.startBrowser();
            error++;
            restarted = true;
    await scrapeAll(browser,urls)
}

}
if(restarted === true){
    restarted = false;
}
if(preventInfiniteLoop === 30){
    return {
        error: 'controller fails'
    }
}
    try{
        var results = await pageScraper.scraper(browserInstance,urls);
        console.log('Resultados : ')
        console.log(results)
         if(results === undefined){
            preventInfiniteLoop++;
            console.log(preventInfiniteLoop);
            if(preventInfiniteLoop < 20){
                await browserInstance.close();
                let error = 0;
                var browser = '';
                while( browser === '' && error != 10){
                    console.log(browser);
                  browser = await browserObject.startBrowser();
                    error++;
                }
            await scrapeAll(browser,urls)

            }
        }
        if(results != 0){

        if(results.error != true){
            console.log(results.results)
            var response = await results.results;
            return response;
        }else if (results.error === true && results.criticalError === true || results === 0
            ){
            preventInfiniteLoop++;
            console.log(preventInfiniteLoop);
                await scrapeAll(browserInstance,urls)
        }else if (results.error === false && results.actualPage != false && results.nextPageUrl != false && results.paginationValue != false){
            console.log(results);
            var newResults = await pageScraper.scraper(browserInstance,results.nextPageUrl, results.paginationValue);
            results.results.concat(await newResults.results);
            
        }else if (results.error === true, results.criticalError != true){
            preventInfiniteLoop++;
            await scrapeAll(browserInstance,urls)
        }
    }

    }
    catch(err){
        console.log("Could not resolve the browser instance (controller : A )=> ", err);
        console.log("error Name : ", err.name);
        "Could not resolve the browser instance => \n" + err
        console.log('result:')
        console.log(results)
        if(results.error === true && results.criticalError){
            var browser = await browserReset();
            await browserInstance.close();
            await scrapeAll(browser,urls)
        }
    }finally{
        return results.results;
    }
}

module.exports = (browserInstance,urls) => scrapeAll(browserInstance,urls)