const e = require("express");
const res = require("express/lib/response");

const amazonScraper = {
    url: '',
    percentage: 30,
    getDiscountValue(oldPrice, newPrice) {
        //x = v1 - v2 | x/v1 * 100
        let difference = oldPrice - newPrice;
        let result = Math.round(difference / oldPrice * 100);
        return result;
    },
    reloadTime:0,
    async setReloadTime(page){
        console.log('Timeout setted')
        this.reloadTime = setTimeout(async () => {
            await page.reload({
                waitUntil: [ "domcontentloaded"]
            });
            console.log(page)
            console.log('Time out')
        }, 10000);
    },
    async unsetTime(){
        console.log('Timeout destroyed')
        clearTimeout(this.reloadTime) ;
    },
    async comprobateActualPage(page){
        let comprobateActualPage = await page.waitForSelector('.s-pagination-selected').then(()=>{
           return page.evaluate(
                async () => 
            {
                if (document.querySelector('.s-pagination-selected') != null) 
                {
    
                    var paginationSelectedValue = await parseInt(document.querySelector('.s-pagination-selected').innerText);
                    var pagination = {
                        actualPage: paginationSelectedValue,
                        nextPageUrl: document.querySelector('.s-pagination-selected').parentNode.querySelector('.s-pagination-next') ? document.querySelector('.s-pagination-selected').parentNode.querySelector('.s-pagination-next').href : false
                    }
                } else 
                {
                    var pagination = {
                        actualPage: 0,
                        nextPageUrl: false
                    }
    
                }
                
                return pagination;
            })

        })
        return comprobateActualPage;
         
    },
    async clickNextPagination(page,comprobateActualPage,maxClicks){
        var res = 0
         await page.waitForSelector('.s-pagination-item.s-pagination-next.s-pagination-button.s-pagination-separator').then(async ()=>{
            if (comprobateActualPage.actualPage <= maxClicks - 1) 
            {
                await page.click('.s-pagination-item.s-pagination-next.s-pagination-button.s-pagination-separator');
                res= true;
                console.log('clicked!')
            } else {
                res= false;
            }
        })
        return res;


    },
    async getData(page) {
console.log('get data initialize');
        await page.viewport({
            width: 1024 + Math.floor(Math.random() * 100),
            height: 768 + Math.floor(Math.random() * 100),
        })
        var finalDataObject = await page.waitForSelector('.s-result-item > .sg-col-inner').then(async ()=>{
            return page.evaluate(() => {

                self = this;
    
    
                function getDiscountValue(oldPrice, newPrice) {
                    //x = v1 - v2 | x/v1 * 100
                    let difference = newPrice - oldPrice;
                    let result = Math.round(difference / oldPrice * 100);
                    return result;
                }
                let finalDataOutput = [];
            var amazonProducts = document.querySelectorAll('.s-result-item > .sg-col-inner')

            for (e of amazonProducts)
             {
                var finalDataObject = {
                    product: '',
                    discount: '',
                    newPrice: '',
                    oldPrice: '',
                    url: '',
                    prime: false
                };


                finalDataObject.product = e.querySelector('.a-section.a-spacing-none.a-spacing-top-small.s-title-instructions-style') != null ? e.querySelector('.a-section.a-spacing-none.a-spacing-top-small.s-title-instructions-style').innerText : e.querySelector('.a-size-medium.a-color-base.a-text-normal').innerText;
                finalDataObject.url = e.querySelector('.a-section.a-spacing-none.a-spacing-top-small.s-title-instructions-style') != null ? e.querySelector('.a-section.a-spacing-none.a-spacing-top-small.s-title-instructions-style').querySelector('a').href : e.querySelector('.a-size-medium.a-color-base.a-text-normal').parentNode.href; //url
                finalDataObject.newPrice = e.querySelector('.a-section .a-spacing-none > div > div > a > span > span.a-offscreen') != null ? e.querySelector('.a-section .a-spacing-none > div > div > a > span > span.a-offscreen').innerText.trim().replace(',', '').replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '') : e.querySelector('.a-size-base.a-link-normal.s-link-style.a-text-normal') != null ? e.querySelector('.a-size-base.a-link-normal.s-link-style.a-text-normal').querySelector('.a-price > span').innerText.trim().replace(',', '').replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '') : null; //new price
                finalDataObject.oldPrice = e.querySelector('.a-section .a-spacing-none > div > div > a > .a-price.a-text-price > .a-offscreen') != null ? e.querySelector('.a-section .a-spacing-none > div > div > a > .a-price.a-text-price > .a-offscreen').innerText.trim().replace(',', '').replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '') : e.querySelector('.a-size-base.a-link-normal.s-link-style.a-text-normal') != null ? e.querySelector('.a-size-base.a-link-normal.s-link-style.a-text-normal').querySelector('.a-price.a-text-price > span') != null ? e.querySelector('.a-size-base.a-link-normal.s-link-style.a-text-normal').querySelector('.a-price.a-text-price > span').innerText.trim().replace(',', '').replace(/[&\/\\#,+()$~%'":*?<>{}]/g, '') : null : null; //old price
                finalDataObject.discount = getDiscountValue(parseFloat(finalDataObject.oldPrice), parseFloat(finalDataObject.newPrice)) < getDiscountValue(parseFloat(finalDataObject.newPrice), parseFloat(finalDataObject.oldPrice)) ? getDiscountValue(parseFloat(finalDataObject.oldPrice), parseFloat(finalDataObject.newPrice)) : getDiscountValue(parseFloat(finalDataObject.newPrice), parseFloat(finalDataObject.oldPrice));
                finalDataObject.prime = e.querySelector('.a-icon.a-icon-prime.a-icon-medium') != null ? true : false;

                if (finalDataObject.oldPrice != null) 
                {
                    finalDataOutput.push(finalDataObject);

                }
            }

            console.log(finalDataOutput);
    
                return Promise.all(finalDataOutput).then(
                    finalDataOutput => 
                    {
                    return finalDataOutput;
                }).catch(e => 
                    {
                    console.log('Error in Promise inside scraper');
                    console.log(e);
                });
    
            })
        })
console.log(finalDataObject);

        return finalDataObject;
    },
    result :{results:[]},
    errorsInNavigation:0,
    async scraper(browser, urls, paginationValue) {
        try {

            this.url = urls;
            let page = (await browser.pages())[0];
            console.log("page in scraping");
            console.log(`Navigating to ${this.url}...`);
            if (page === undefined){
                result = {
                    results: false,
                    pagination: false,
                    error: true,
                    nextPageUrl:false,
                    criticalError : true,
                    paginationValue: false
                };
                return this.result;
            }
                await page.goto(this.url, {
                    waitUntil: [ "domcontentloaded"],
                    timeout: 0
                });
                page.on("pageerror", async function(err) { 
                    console.log('Page error:'); 
                    console.log(err); 
                    console.log(this.result);

                    await page.reload();
                   await page.waitForNavigation();
                });

                page.on('error', async (err) => {
                    console.log('Page error 2:'); 
                    console.log(err); 
                    console.log(this.result);

                    await page.reload();
                   await page.waitForNavigation();
                });
                
            await page.setDefaultNavigationTimeout(0);
            await page.setDefaultTimeout(0);
 
                if (paginationValue === undefined){
                    var maxClicks = await page.waitForSelector('.a-section.a-spacing-small.a-spacing-top-small').then(()=>{
                        return page.evaluate(async () => {
                        let str = document.querySelector('.a-section.a-spacing-small.a-spacing-top-small').innerText.split(" ")
                        let resultsPerPage = parseInt(str[0].split('-').pop());
                        let totalResults = str.map((e) => {
                            return parseInt(e.replace(',', ''))
                        }).filter(Boolean).pop()
                        let maxClicks = await Math.ceil(totalResults / resultsPerPage);
        
                        return maxClicks;
                    })
                })
                }else{
                    var maxClicks = await page.waitForSelector('.a-section.a-spacing-small.a-spacing-top-small').then(()=>{
                        return page.evaluate(async () => {
                        let str = document.querySelector('.a-section.a-spacing-small.a-spacing-top-small').innerText.split(" ")
                        let resultsPerPage = parseInt(str[0].split('-').pop());
                        let totalResults = str.map((e) => {
                            return parseInt(e.replace(',', ''))
                        }).filter(Boolean).pop()
                        let maxClicks = await Math.ceil(totalResults / resultsPerPage);
        
                        return maxClicks;
                    })
                })
                    maxClicks = paginationValue - maxClicks;
                }
                console.log('pagination value')
                console.log(paginationValue);
                console.log('maxClicks: ')
                console.log(maxClicks)

            console.log('Max cliccks: ');
            console.log(maxClicks);
            var finalDataOutput = [];
            var comprobateActualPage = {
                actualPage: 0
            };
            var lastArr = [];
            var errors = 0;
            for (let i = 0; parseInt(comprobateActualPage.actualPage) < maxClicks; i++) {
                console.log('bucle start')
             

                if((await page.$('.a-box-inner.a-padding-extra-large')) != null){
                    result = {
                        results: false,
                        pagination: false,
                        error: true,
                        nextPageUrl:false,
                        criticalError : true,
                        paginationValue: false
                    };
                    return this.result;
                }
                var tempArr =[];
                if(comprobateActualPage.actualPage <= maxClicks - 1) {
                console.log('bucle 1 step before comprobations')

                    tempArr = await this.getData(page);
                    console.log('Temp arr');
                    console.log(tempArr);


                    if (lastArr.length > 0) 
                    {
                console.log('bucle temparr not empty')

                            if (lastArr[0] != tempArr[0]) 
                            {
                                lastArr = tempArr;
                                 finalDataOutput = await finalDataOutput.concat(await tempArr);
                                 await this.unsetTime()
                                 comprobateActualPage = await this.comprobateActualPage(page);
                                 this.result = {
                                    results: finalDataOutput,
                                    pagination: comprobateActualPage.actualPage != false ? comprobateActualPage.actualPage : false,
                                    nextPageUrl: comprobateActualPage.nextPageUrl != false ? comprobateActualPage.nextPageUrl : false,
                                    error: false,
                                    paginationValue: comprobateActualPage.nextPageUrl != false ? maxClicks : false
                                };
                               var  clicked = await this.clickNextPagination(page,comprobateActualPage,maxClicks) ;
                               if(clicked === false){
                                   break;
                               }


                            }
                        

                    } else {
                console.log('bucle tempar empty')
                        
                        var tempArr = await this.getData(page);
                        
                        lastArr = tempArr;
                        finalDataOutput = await finalDataOutput.concat(await tempArr);
                        await this.unsetTime()

                        comprobateActualPage = await this.comprobateActualPage(page);
                        this.result = {
                           results: finalDataOutput,
                           pagination: comprobateActualPage.actualPage != false ? comprobateActualPage.actualPage : false,
                           nextPageUrl: comprobateActualPage.nextPageUrl != false ? comprobateActualPage.nextPageUrl : false,
                           error: false,
                           paginationValue: comprobateActualPage.nextPageUrl != false ? maxClicks : false
                       };
                        var  clicked = await this.clickNextPagination(page,comprobateActualPage,maxClicks) ;
                        if(clicked === false){
                            break;
                        }

                    }



                } else 
                {
                console.log('break final assign')
                finalDataOutput = await finalDataOutput.concat(await this.getData(page));
                    this.result.results = finalDataOutput;
                    break;
                }

                comprobateActualPage = await this.comprobateActualPage(page);
                console.log('this.result log : ')
                console.log(this.result)

            }

            this.result = {
                results: finalDataOutput,
                pagination: comprobateActualPage.actualPage != 0 ? comprobateActualPage.actualPage : false,
                error: false,
                nextPageUrl: comprobateActualPage.nextPageUrl != false ? comprobateActualPage.nextPageUrl : false,
                paginationValue: comprobateActualPage.actualPage != 0 ? maxClicks : false
            };
            if(this.result.result != false && this.result.error === false && this.result.paginationValue >= maxClicks){
                return this.result;
            }

        } catch (e) 
        {
            console.log('ERROR IN SCRAPPER (UNNESESARY RESET?)');
            console.log(e);
            console.log("error Name : ", e.name);
            let page = (await browser.pages())[0];
            if(page === undefined){

                this.result= undefined;
            }
            var comprobateActualPage = await this.comprobateActualPage(page);
            if(this.result.results.length === 0){
                this.result = {
                    results: false,
                    pagination: comprobateActualPage.actualPage != false ? comprobateActualPage.actualPage : false,
                    nextPageUrl: comprobateActualPage.nextPageUrl != false ? comprobateActualPage.nextPageUrl : false,
                    error: true,
                    paginationValue: comprobateActualPage.nextPageUrl != false ? maxClicks : false
                };
            }

        } finally 
        {

            console.log('comprobateActualPage : ');
            console.log(comprobateActualPage);
            console.log('results : ');
            console.log(this.result)
if(this.result.results.length === 0 ){
    this.result = {
        results: false,
        pagination: comprobateActualPage.actualPage != false ? comprobateActualPage.actualPage : false,
        nextPageUrl: comprobateActualPage.nextPageUrl != false ? comprobateActualPage.nextPageUrl : false,
        error: true,
        paginationValue: comprobateActualPage.nextPageUrl != false ? maxClicks : false
    };
    return this.result
}


            if (this.result.nextPageUrl === false && this.result.error === true && this.result.results.length != 0) 
            {
                console.log('good end case')
                return this.result;
            } else if (this.result.nextPageUrl != false && this.result.error === true && this.result.results.length === 0) 
            {
                console.log('repeat case')
                this.scraper(browser, result.nextPageUrl, {
                    errorInNavigationCaseWithNextUrl: true
                });
            } else if (this.result.nextPageUrl === false && this.result.error === true && this.result.results === false && this.result.nextPageUrl === false || this.result === 0 && comprobateActualPage === false) 
            {
                console.log('critical error case')
                result = {
                    results: false,
                    pagination: false,
                    error: true,
                    nextPageUrl:false,
                    criticalError : true,
                    paginationValue: false
                };
                return this.result;
            } else 
            {
                return this.result;
            }

        }

    },

}

module.exports = amazonScraper;